java -cp tetris.jar com.tarena.tetris.Tetris
